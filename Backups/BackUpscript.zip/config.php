<?php

$host = 'localhost';
$dbname = 'evesystems';
$username = 'root';
$password = 'R4twing51';